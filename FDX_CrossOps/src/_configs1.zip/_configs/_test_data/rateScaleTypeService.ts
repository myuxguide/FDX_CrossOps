export const rateScaleTypeService = [{
    "type" : "Shipment Weight Base"
}];