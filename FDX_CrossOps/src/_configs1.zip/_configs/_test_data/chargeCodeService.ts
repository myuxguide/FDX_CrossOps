export const chargeCode = [{
    "chargeCd" : "687",
    "chargeDesc" : "Additional Handling - Weight (EXP)"
  }, {
    "chargeCd" : "892",
    "chargeDesc" : "AHS Freight"
  }, {
    "chargeCd" : "043",
    "chargeDesc" : "Outside Delivery Area"
  }, {
    "chargeCd" : "688",
    "chargeDesc" : "Additional Handling Charge - Dimensions (EXP)"
  }, {
    "chargeCd" : "912",
    "chargeDesc" : "Additional Handling Charge - Non-stackable"
  }, {
    "chargeCd" : "022",
    "chargeDesc" : "Residential Delivery"
  }, {
    "chargeCd" : "003",
    "chargeDesc" : "Saturday Pickup"
  }, {
    "chargeCd" : "312",
    "chargeDesc" : "Addl Handling Charge - Package"
  }, {
    "chargeCd" : "002",
    "chargeDesc" : "Saturday Delivery"
  }, {
    "chargeCd" : "CVI",
    "chargeDesc" : "Non-Electronic Consignment Charge"
  }, {
    "chargeCd" : "CVH",
    "chargeDesc" : "Toll"
  }, {
    "chargeCd" : "007",
    "chargeDesc" : "Address Correction"
  }, {
    "chargeCd" : "042",
    "chargeDesc" : "Outside Pickup Area"
  }];
