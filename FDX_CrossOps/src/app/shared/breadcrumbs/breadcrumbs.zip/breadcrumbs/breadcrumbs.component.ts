import { Component, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { BreadcrumbsService } from './breadcrumbs.service';

@Component({
  selector: 'app-breadcrumbs',
  templateUrl: './breadcrumbs.component.html',
  styleUrls: ['./breadcrumbs.component.css']
})
export class BreadcrumbsComponent implements OnInit {
  moduleName: string;
  time = new Date();
  timer;

  constructor(public dialog: MatDialog,
    private breadCrumbService: BreadcrumbsService,) { }

  ngOnInit(): void {
    
      this.breadCrumbService.currentPage.subscribe(moduleName => {
        this.moduleName = moduleName;
      });
  
      this.timer = setInterval(() => {
        this.time = new Date();
      }, 1000);
    
  } 
  ngOnDestroy() {
    clearInterval(this.timer);
  }
  refreshPolicyGrid() {
  }
}
